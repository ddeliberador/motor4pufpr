# Guia de Correção — Motor 4P UFPR

## O que foi corrigido

### layer-knowledge/index.ts
- CAPES: URL correta da API CKAN + fallback para dados.gov.br
- OpenAlex: User-Agent com email (polite pool = sem throttle, 100k req/dia)
- Novo campo `total_papers_global` para calcular share BR vs mundo
- Timeout aumentado de 12s → 20s

### layer-policy/index.ts
- **CORREÇÃO CRÍTICA**: Portal da Transparência exige header `chave-api`
  Sem ele, retorna 401 em 100% das chamadas
  Agora lê a chave do secret `TRANSPARENCIA_API_KEY`
  Fallback automático para dados.gov.br se chave não configurada
- PNCP: parâmetros corrigidos + fallback
- Timeout aumentado para 25s nas chamadas de governo

### layer-technology/index.ts
- GitHub: suporte a `GITHUB_TOKEN` (opcional)
  Sem token: 60 req/hora (rate limit rápido)
  Com token: 5.000 req/hora
- Timeout aumentado para 20s

### layer-international/index.ts
- **CORREÇÃO**: IPEAData usava `http://` — Edge Functions do Supabase
  bloqueiam HTTP, só aceitam HTTPS
  Corrigido para `https://www.ipeadata.gov.br/...`
- Timeout aumentado para 20s

### motor-analysis/index.ts
- Suporte a dois provedores de IA (Lovable Gateway + Anthropic API como fallback)
- Prompt reformulado com dados por camada mais detalhados
- Lógica de fallback: tenta Lovable → se falhar, tenta Anthropic
- Mensagem de erro clara quando nenhuma chave está configurada

### motor-search/index.ts
- Timeout do invokeLayer aumentado de default → 45s
  (as 4 layers em paralelo precisam desse tempo nas APIs do governo)

---

## Passo 1 — Configurar Secrets no Supabase

Acesse: **supabase.com → seu projeto → Settings → Edge Functions → Secrets**

### Secrets obrigatórios

| Secret | Onde obter | Prioridade |
|--------|-----------|------------|
| `LOVABLE_API_KEY` | Já deve existir no projeto Lovable | Obrigatório para IA |
| `TRANSPARENCIA_API_KEY` | Ver instruções abaixo | Obrigatório para convênios |

### Secrets opcionais (mas recomendados)

| Secret | Onde obter | Benefício |
|--------|-----------|-----------|
| `GITHUB_TOKEN` | github.com/settings/tokens | Rate limit 60 → 5.000 req/hora |
| `ANTHROPIC_API_KEY` | console.anthropic.com | Fallback de IA se Lovable falhar |

### Como obter a TRANSPARENCIA_API_KEY (gratuito)

1. Acesse: https://portaldatransparencia.gov.br/api-de-dados/api-swaggerui
2. Clique em **"Solicitar chave de API"**
3. Preencha com email institucional (UFPR)
4. Você recebe a chave por email em minutos
5. Adicione no Supabase como `TRANSPARENCIA_API_KEY`

### Como criar o GITHUB_TOKEN (gratuito)

1. Acesse: https://github.com/settings/tokens
2. Clique em **"Generate new token (classic)"**
3. Name: `motor4p-ufpr`
4. Expiration: `No expiration`
5. **Não marque nenhum scope** (acesso público já é suficiente)
6. Clique em **"Generate token"**
7. Copie e adicione no Supabase como `GITHUB_TOKEN`

---

## Passo 2 — Substituir os arquivos no Lovable

Substitua os seguintes arquivos no seu projeto:

```
supabase/functions/layer-knowledge/index.ts   ← corrigido
supabase/functions/layer-policy/index.ts      ← corrigido (crítico)
supabase/functions/layer-technology/index.ts  ← corrigido
supabase/functions/layer-international/index.ts ← corrigido
supabase/functions/motor-search/index.ts      ← corrigido
supabase/functions/motor-analysis/index.ts    ← corrigido
```

No Lovable, você pode editar diretamente pelos arquivos ou colar o conteúdo.

---

## Passo 3 — Publicar

1. No Lovable, clique em **Publish**
2. Aguarde o deploy das Edge Functions (1-2 minutos)
3. Teste buscando por: `grafeno`, `baterias de lítio`, ou `semicondutores`

---

## Passo 4 — Verificar se funcionou

Abra o console do navegador (F12 → Console) após uma busca.
Você deve ver:
- ✅ `layer-knowledge` retornando papers do OpenAlex
- ✅ `layer-technology` retornando repos do GitHub
- ✅ `layer-policy` retornando contratos do PNCP
- ✅ `motor-analysis` gerando prescrição com dados reais

Se ainda houver erros:
- `401 Transparência` → `TRANSPARENCIA_API_KEY` não configurada
- `403 GitHub` → Token inválido ou expirado
- `AI not configured` → Nem `LOVABLE_API_KEY` nem `ANTHROPIC_API_KEY` configurados
- `timeout` → APIs do governo lentas, é normal — sistema tem fallback

---

## Ordem de prioridade das correções

1. **Configure `TRANSPARENCIA_API_KEY`** — desbloqueia convênios e sanções
2. **Substitua `layer-policy/index.ts`** — correção mais impactante
3. **Substitua `motor-analysis/index.ts`** — prescrições muito mais ricas
4. Substitua os outros 4 arquivos — melhorias de robustez e dados

---

## Por que o sistema vai funcionar melhor agora

Antes das correções:
- Portal da Transparência: 0 resultados (sem chave de API)
- IPEAData: 0 resultados (HTTP bloqueado em Edge Functions)
- GitHub: rate limit frequente (sem token)
- IA: análise genérica (prompt sem dados detalhados por camada)

Depois das correções:
- Portal da Transparência: convênios e sanções reais
- IPEAData: séries macroeconômicas (Selic, câmbio, crédito PJ)
- GitHub: 5.000 req/hora com token
- IA: prescrições baseadas em GT/CD/AUE/EI com dados concretos
